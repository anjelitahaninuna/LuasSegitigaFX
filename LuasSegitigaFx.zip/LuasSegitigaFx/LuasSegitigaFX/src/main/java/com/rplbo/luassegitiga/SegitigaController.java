package com.rplbo.luassegitiga;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SegitigaController {
    @FXML
    private Label lblHasil;
    @FXML
    private TextField txtAlas;
    @FXML
    private TextField txtTinggi;
    @FXML
    private Button btnClose;

    @FXML
    protected void onBtnLuasClick() {
        int alas = Integer.parseInt(txtAlas.getText());
        int tinggi = Integer.parseInt(txtTinggi.getText());
        double hasil = 0.5 * alas * tinggi;
        lblHasil.setText("Hasil: "+hasil);
    }

    @FXML
    protected void onCloseBtnClick(){
        Stage stage = (Stage) btnClose.getScene().getWindow();
        stage.close();
    }
}