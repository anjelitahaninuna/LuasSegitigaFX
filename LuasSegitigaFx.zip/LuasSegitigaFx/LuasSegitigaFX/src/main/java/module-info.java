module com.rplbo.luassegitiga {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;

    opens com.rplbo.luassegitiga to javafx.fxml;
    exports com.rplbo.luassegitiga;
}